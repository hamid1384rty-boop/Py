package com.pyrunner.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        const val PREFS = "pyrunner"
        const val KEY_FILES = "files"
        const val KEY_URL = "panel_url"
        const val DEFAULT_URL = "http://127.0.0.1:5000/"

        fun panelUrl(ctx: Context): String =
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL

        private val BG = 0xFF101316.toInt()
        private val CARD = 0xFF181C21.toInt()
        private val LINE = 0xFF2A3038.toInt()
        private val FG = 0xFFE7EAEE.toInt()
        private val MUTED = 0xFF8D96A3.toInt()
        private val ACCENT = 0xFF2DD4BF.toInt()
        private val ACCENT_INK = 0xFF062B28.toInt()
        private val RUN = 0xFFF59E0B.toInt()
        private val STOP = 0xFFF87171.toInt()
        private val WHITE = 0xFFFFFFFF.toInt()
        private val CODE_BG = 0xFF0A0D10.toInt()
        private val CODE_FG = 0xFFCFD8E0.toInt()
    }

    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val scriptsDir by lazy { File(filesDir, "scripts").apply { mkdirs() } }
    private val dataRoot by lazy { File(filesDir, "data").apply { mkdirs() } }
    private val logDir by lazy { File(filesDir, "logs").apply { mkdirs() } }
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var files = mutableListOf<String>()
    private var runningName: String? = null
    private var activeLog: File? = null

    private lateinit var listBox: LinearLayout
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var urlView: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFile(uri)
    }

    private val poller = object : Runnable {
        override fun run() {
            refreshLog()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        files = loadList()
        buildUi()
        ui.post(poller)
    }

    override fun onDestroy() {
        ui.removeCallbacks(poller)
        if (isFinishing) stopRun()
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        // Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("Py Runner", 22f, FG, bold = true))
        titles.addView(label("اجرای فایل‌های پایتون روی گوشی", 12f, MUTED))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(button("+ افزودن", filled = true) { picker.launch(arrayOf("*/*")) })
        root.addView(header, matchWrap(bottom = 16))

        // File list
        val scroll = ScrollView(this)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Status line
        statusView = label("بدون اجرا", 12f, MUTED).apply { setPadding(0, dp(10), 0, dp(6)) }
        root.addView(statusView)

        // Log header + log box
        val logHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        logHeader.addView(label("خروجی", 13f, FG, bold = true), LinearLayout.LayoutParams(0, WRAP, 1f))
        logHeader.addView(button("پاک کردن", filled = false, color = MUTED) {
            logView.text = ""
            activeLog?.writeText("")
        })
        root.addView(logHeader)

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(CODE_FG)
            setTextIsSelectable(true)
        }
        val logScroll = ScrollView(this).apply {
            background = rounded(CODE_BG, 14, LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(logView)
        }
        root.addView(logScroll, LinearLayout.LayoutParams(MATCH, 0, 1.1f).apply { topMargin = dp(6) })

        // Footer: panel address + buttons
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        urlView = label("", 12f, MUTED, mono = true)
        footer.addView(urlView, LinearLayout.LayoutParams(0, WRAP, 1f))
        footer.addView(button("آدرس پنل", filled = false, color = ACCENT) { editPanelUrl() })
        footer.addView(button("نمایش پنل", filled = true) {
            startActivity(Intent(this, WebActivity::class.java))
        })
        root.addView(footer, matchWrap(top = 10))

        setContentView(root)
        refreshUrl()
        renderList()
    }

    private fun renderList() {
        listBox.removeAllViews()
        if (files.isEmpty()) {
            listBox.addView(label("هنوز فایلی نیست. با «+ افزودن» یک فایل .py انتخاب کن.", 14f, MUTED)
                .apply { setPadding(dp(4), dp(24), dp(4), 0) })
            return
        }
        for (name in files) {
            val isRunning = runningName == name

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(CARD, 16, LINE)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }

            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(name, 13f, FG, mono = true))
            info.addView(label(
                if (isRunning) "● در حال اجرا" else "داده: data/${safe(name)}",
                11f,
                if (isRunning) RUN else MUTED
            ))
            top.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
            top.addView(button("🗑 حذف", filled = false, color = STOP) { confirmDelete(name) })
            card.addView(top)

            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(10), 0, 0)
            }
            if (isRunning) {
                actions.addView(button("⏹ توقف", filled = true, color = STOP) { stopRun() })
            } else {
                actions.addView(button("▶ استارت", filled = true) { startRun(name) })
            }
            actions.addView(button("پاک‌سازی داده", filled = false, color = MUTED) { clearData(name) }
                .apply { isEnabled = !isRunning })
            card.addView(actions)

            listBox.addView(card, matchWrap(bottom = 10))
        }
    }

    private fun refreshUrl() {
        urlView.text = "آدرس پنل: ${panelUrl(this)}"
    }

    // ---------- Files ----------

    private fun importFile(uri: Uri) {
        io.execute {
            val raw = displayName(uri).ifBlank { "script_${System.currentTimeMillis()}.py" }
            if (!raw.endsWith(".py", ignoreCase = true)) {
                ui.post { statusView.text = "فقط فایل‌های .py پشتیبانی می‌شوند" }
                return@execute
            }
            val name = safe(raw)
            contentResolver.openInputStream(uri)?.use { input ->
                File(scriptsDir, name).outputStream().use { input.copyTo(it) }
            }
            ui.post {
                if (name !in files) files.add(name)
                saveList()
                renderList()
            }
        }
    }

    private fun confirmDelete(name: String) {
        AlertDialog.Builder(this)
            .setTitle("حذف فایل")
            .setMessage("«$name» و داده‌ی آن پاک شود؟")
            .setPositiveButton("حذف") { _, _ -> deleteScript(name) }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun deleteScript(name: String) {
        if (runningName == name) stopRun()
        files.remove(name)
        saveList()
        val logName = "${safe(name)}.log"
        if (activeLog?.name == logName) {
            activeLog = null
            logView.text = ""
        }
        io.execute {
            File(scriptsDir, name).delete()
            File(dataRoot, safe(name)).deleteRecursively()
            File(logDir, logName).delete()
        }
        statusView.text = "«$name» حذف شد"
        renderList()
    }

    private fun clearData(name: String) {
        io.execute { File(dataRoot, safe(name)).deleteRecursively() }
        statusView.text = "داده‌ی $name پاک شد"
    }

    // ---------- Run ----------

    private fun startRun(name: String) {
        stopRun()
        val dataDir = File(dataRoot, safe(name)).apply { mkdirs() }
        val script = File(scriptsDir, name).absolutePath
        val log = File(logDir, "${safe(name)}.log").apply { writeText("") }
        activeLog = log
        logView.text = ""
        runningName = name
        statusView.text = "در حال اجرا: $name"
        renderList()
        io.execute {
            runCatching {
                Python.getInstance().getModule("runner")
                    .callAttr("start", script, dataDir.absolutePath, log.absolutePath)
            }.onFailure { e -> log.appendText("\n[Kotlin] ${e.message}\n") }
        }
    }

    private fun stopRun() {
        if (runningName == null) return
        io.execute {
            runCatching { Python.getInstance().getModule("runner").callAttr("stop") }
        }
        runningName = null
        statusView.text = "متوقف شد"
        renderList()
    }

    private fun refreshLog() {
        val log = activeLog ?: return
        val text = if (log.exists()) log.readText() else ""
        if (text != logView.text.toString()) logView.text = text
        if (runningName != null) {
            val alive = runCatching {
                Python.getInstance().getModule("runner").callAttr("is_running").toBoolean()
            }.getOrDefault(false)
            if (!alive) {
                runningName = null
                statusView.text = "پایان یافت"
                renderList()
            }
        }
    }

    // ---------- Panel address ----------

    private fun editPanelUrl() {
        val input = EditText(this).apply {
            setText(panelUrl(this@MainActivity))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 1
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("آدرس پنل")
            .setMessage("پیش‌فرض: $DEFAULT_URL\nاگر اسکریپت روی پورت دیگری اجرا می‌شود، همان آدرس را اینجا بنویس.")
            .setView(input)
            .setPositiveButton("ذخیره") { _, _ ->
                var v = input.text.toString().trim()
                if (v.isEmpty()) v = DEFAULT_URL
                if (!v.startsWith("http://") && !v.startsWith("https://")) v = "http://$v"
                if (!v.endsWith("/")) v += "/"
                prefs.edit().putString(KEY_URL, v).apply()
                refreshUrl()
            }
            .setNeutralButton("پیش‌فرض") { _, _ ->
                prefs.edit().putString(KEY_URL, DEFAULT_URL).apply()
                refreshUrl()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- Helpers ----------

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
        }
        return uri.lastPathSegment ?: ""
    }

    private fun safe(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun loadList(): MutableList<String> {
        val arr = JSONArray(prefs.getString(KEY_FILES, "[]") ?: "[]")
        return MutableList(arr.length()) { arr.getString(it) }
    }

    private fun saveList() {
        prefs.edit().putString(KEY_FILES, JSONArray(files).toString()).apply()
    }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun matchWrap(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            if (mono) typeface = Typeface.MONOSPACE
        }

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun button(
        label: String,
        filled: Boolean,
        color: Int = ACCENT,
        onClick: () -> Unit
    ): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(12), dp(6), dp(12), dp(6))
        background = if (filled) rounded(color, 12) else rounded(0x00000000, 12, color)
        setTextColor(
            when {
                !filled -> color
                color == ACCENT || color == RUN -> ACCENT_INK
                else -> WHITE
            }
        )
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(6) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
