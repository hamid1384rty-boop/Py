package com.pyrunner.app

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("pyrunner", Context.MODE_PRIVATE) }
    private val scriptsDir by lazy { File(filesDir, "scripts").apply { mkdirs() } }
    private val dataRoot by lazy { File(filesDir, "data").apply { mkdirs() } }
    private val logDir by lazy { File(filesDir, "logs").apply { mkdirs() } }
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var files = mutableListOf<String>()
    private var runningName: String? = null
    private var activeLog: File? = null

    private lateinit var listBox: LinearLayout
    private lateinit var logView: TextView
    private lateinit var statusView: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFile(uri)
    }

    private val poller = object : Runnable {
        override fun run() {
            refreshLog()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        files = loadList()
        buildUi()
        ui.post(poller)
    }

    override fun onDestroy() {
        ui.removeCallbacks(poller)
        if (isFinishing) stopRun()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "Py Runner"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(Button(this).apply {
            text = "+ افزودن فایل"
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        })
        root.addView(header)

        val scroll = ScrollView(this)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        statusView = TextView(this).apply {
            text = "بدون اجرا"
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(statusView)

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(0xFFD6E2EA.toInt())
            setTextIsSelectable(true)
        }
        val logScroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0F1419.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(logView)
        }
        root.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.2f))

        root.addView(Button(this).apply {
            text = "نمایش صفحه‌ی وب (127.0.0.1:5000)"
            setOnClickListener { startActivity(Intent(this@MainActivity, WebActivity::class.java)) }
        })

        setContentView(root)
        renderList()
    }

    private fun renderList() {
        listBox.removeAllViews()
        if (files.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "هنوز فایلی اضافه نشده. با «افزودن فایل» یک فایل .py انتخاب کن."
                setPadding(0, dp(24), 0, 0)
            })
        }
        for (name in files) {
            val isRunning = runningName == name
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
            }
            row.addView(TextView(this).apply {
                text = name
                typeface = Typeface.MONOSPACE
                textSize = 13f
            })
            row.addView(TextView(this).apply {
                text = if (isRunning) "در حال اجرا" else "آماده · داده: data/${safe(name)}"
                textSize = 11f
            })
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(Button(this).apply {
                text = if (isRunning) "⏹ توقف" else "▶ استارت"
                setOnClickListener { if (isRunning) stopRun() else startRun(name) }
            })
            btns.addView(Button(this).apply {
                text = "پاک‌سازی داده"
                isEnabled = !isRunning
                setOnClickListener { clearData(name) }
            })
            row.addView(btns)
            listBox.addView(row)
        }
    }

    private fun importFile(uri: Uri) {
        io.execute {
            val raw = displayName(uri).ifBlank { "script_${System.currentTimeMillis()}.py" }
            if (!raw.endsWith(".py", ignoreCase = true)) {
                ui.post { statusView.text = "فقط فایل‌های .py پشتیبانی می‌شوند" }
                return@execute
            }
            val name = safe(raw)
            contentResolver.openInputStream(uri)?.use { input ->
                File(scriptsDir, name).outputStream().use { input.copyTo(it) }
            }
            ui.post {
                if (name !in files) files.add(name)
                saveList()
                renderList()
            }
        }
    }

    private fun startRun(name: String) {
        stopRun()
        val dataDir = File(dataRoot, safe(name)).apply { mkdirs() }
        val script = File(scriptsDir, name).absolutePath
        val log = File(logDir, "${safe(name)}.log").apply { writeText("") }
        activeLog = log
        logView.text = ""
        runningName = name
        statusView.text = "در حال اجرا: $name"
        renderList()
        io.execute {
            runCatching {
                Python.getInstance().getModule("runner")
                    .callAttr("start", script, dataDir.absolutePath, log.absolutePath)
            }.onFailure { e -> log.appendText("\n[Kotlin] ${e.message}\n") }
        }
    }

    private fun stopRun() {
        if (runningName == null) return
        io.execute {
            runCatching { Python.getInstance().getModule("runner").callAttr("stop") }
        }
        runningName = null
        statusView.text = "متوقف شد"
        renderList()
    }

    private fun clearData(name: String) {
        File(dataRoot, safe(name)).deleteRecursively()
        statusView.text = "داده‌ی $name پاک شد"
    }

    private fun refreshLog() {
        val log = activeLog ?: return
        val text = if (log.exists()) log.readText() else ""
        if (text != logView.text.toString()) logView.text = text
        if (runningName != null) {
            val alive = runCatching {
                Python.getInstance().getModule("runner").callAttr("is_running").toBoolean()
            }.getOrDefault(false)
            if (!alive) {
                runningName = null
                statusView.text = "پایان یافت"
                renderList()
            }
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
        }
        return uri.lastPathSegment ?: ""
    }

    private fun safe(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun loadList(): MutableList<String> {
        val arr = JSONArray(prefs.getString("files", "[]") ?: "[]")
        return MutableList(arr.length()) { arr.getString(it) }
    }

    private fun saveList() {
        prefs.edit().putString("files", JSONArray(files).toString()).apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
