"""Runs a user's .py file on the phone and exposes start / stop / status to Kotlin.

- Each script runs in a fresh namespace (runpy), so globals do not leak between runs.
- Its working directory and PYRUNNER_DATA point to a per-file data folder, so files it
  writes there persist across runs.
- stdout/stderr go to a log file that the Kotlin UI polls.
- Flask's app.run() is routed through make_server so stop() can shut the server down.
"""
import ctypes
import os
import runpy
import sys
import threading
import traceback

import werkzeug.serving as _wz

_state = {"running": False, "stop_requested": False, "thread": None, "server": None}


def _run_simple_hook(hostname, port, application, *args, **kwargs):
    # Replaces werkzeug.run_simple (used by Flask's app.run) with a stoppable server.
    from werkzeug.serving import make_server

    srv = make_server(hostname, port, application, threaded=True)
    _state["server"] = srv
    try:
        srv.serve_forever()
    finally:
        srv.server_close()
        _state["server"] = None


_wz.run_simple = _run_simple_hook


def _worker(script, data_dir, log_path):
    logf = open(log_path, "a", encoding="utf-8", buffering=1)
    old_out, old_err, old_cwd = sys.stdout, sys.stderr, os.getcwd()
    sys.stdout = sys.stderr = logf
    try:
        os.environ["PYRUNNER_DATA"] = data_dir
        os.chdir(data_dir)
        print("▶ python " + os.path.basename(script))
        runpy.run_path(script, run_name="__main__")
        print("[exit code 0]")
    except SystemExit as e:
        print("[stopped]" if _state["stop_requested"] else "[exit %s]" % (e.code,))
    except BaseException:
        traceback.print_exc()
        print("[exit with error]")
    finally:
        sys.stdout, sys.stderr = old_out, old_err
        os.chdir(old_cwd)
        logf.close()
        _state["running"] = False


def start(script, data_dir, log_path):
    if _state["running"]:
        return "busy"
    os.makedirs(data_dir, exist_ok=True)
    _state["running"] = True
    _state["stop_requested"] = False
    t = threading.Thread(target=_worker, args=(script, data_dir, log_path), daemon=True)
    _state["thread"] = t
    t.start()
    return "started"


def is_running():
    return bool(_state["running"])


def stop():
    _state["stop_requested"] = True
    srv = _state.get("server")
    if srv is not None:
        try:
            srv.shutdown()
        except Exception:
            pass
    t = _state.get("thread")
    if t is not None and t.is_alive() and t.ident is not None:
        # Script without a server: raise SystemExit inside its thread.
        ctypes.pythonapi.PyThreadState_SetAsyncExc(
            ctypes.c_ulong(t.ident), ctypes.py_object(SystemExit)
        )
    _state["running"] = False
    return "stopped"
