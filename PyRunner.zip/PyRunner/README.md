# Py Runner

Android app that runs a user-picked `.py` file on the phone (Chaquopy) and shows
its web page (127.0.0.1:5000) in a WebView.

Build: push to GitHub (the workflow builds `app-debug.apk` as an artifact),
or open the folder in Android Studio and run.
